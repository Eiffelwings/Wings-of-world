---
name: tar-hook
description: Fixture hook
metadata: {"mechanical-wings":{"events":["command:new"]}}
---

# tar-hook

---
name: reserved-hook
description: Fixture hook
metadata: {"mechanical-wings":{"events":["command:new"]}}
---

# reserved-hook

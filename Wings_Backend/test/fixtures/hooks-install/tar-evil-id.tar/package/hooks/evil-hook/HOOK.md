---
name: evil-hook
description: Fixture hook
metadata: {"mechanical-wings":{"events":["command:new"]}}
---

# evil-hook
